
UPDATE jiveVersion set version=9 where name = 'openfire';
